x=1
y=2
println(x+y)
using Plots
plot(cos)
